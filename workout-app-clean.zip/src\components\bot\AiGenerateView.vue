<template>
  <div class="px-4 py-4 pb-32">
    <div class="text-center mb-5">
      <div class="text-4xl mb-2">✨</div>
      <h2 class="text-xl font-bold text-gray-900">Générer une séance</h2>
      <p class="text-sm text-gray-500 mt-1">L'IA crée une séance adaptée à ton profil</p>

      <!-- Quota -->
      <div class="mt-3 inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs"
        :style="quotaReached ? 'background:#FEE2E2;color:#991B1B' : 'background:#F0F4F8;color:#475569'">
        <span>⚡</span>
        {{ bot.todayUsage }} / {{ bot.dailyQuota }} générations aujourd'hui
      </div>
    </div>

    <div class="space-y-4">
      <!-- Objectif -->
      <div class="card p-4">
        <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Objectif</p>
        <div class="grid grid-cols-2 gap-2">
          <button v-for="opt in objectiveOptions" :key="opt.value"
            type="button"
            @click="form.objective = opt.value"
            class="p-3 rounded-xl text-sm font-medium transition-all flex flex-col items-center gap-1"
            :style="form.objective === opt.value
              ? `background:${opt.color};color:white`
              : 'background:#f9fafb;color:#475569'">
            <span class="text-xl">{{ opt.icon }}</span>
            {{ opt.label }}
          </button>
        </div>
      </div>

      <!-- Durée -->
      <div class="card p-4">
        <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Durée</p>
        <div class="grid grid-cols-5 gap-2">
          <button v-for="d in [15, 30, 45, 60, 90]" :key="d"
            type="button"
            @click="form.duration = d"
            class="py-2 rounded-xl text-sm font-medium transition-all"
            :style="form.duration === d
              ? 'background:var(--brand);color:white'
              : 'background:#f9fafb;color:#475569'">
            {{ d }}<span class="text-xs">min</span>
          </button>
        </div>
      </div>

      <!-- Matériel -->
      <div class="card p-4">
        <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Matériel</p>
        <div class="grid grid-cols-2 gap-2">
          <button v-for="opt in equipmentOptions" :key="opt.value"
            type="button"
            @click="form.equipment = opt.value"
            class="p-3 rounded-xl text-sm font-medium transition-all flex flex-col items-center gap-1"
            :style="form.equipment === opt.value
              ? 'background:var(--brand);color:white'
              : 'background:#f9fafb;color:#475569'">
            <span class="text-xl">{{ opt.icon }}</span>
            <span class="text-xs">{{ opt.label }}</span>
          </button>
        </div>
      </div>

      <!-- À éviter -->
      <div class="card p-4">
        <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">
          À éviter (optionnel)
        </p>
        <div class="flex flex-wrap gap-2">
          <button v-for="g in avoidableGroups" :key="g"
            type="button"
            @click="toggleAvoid(g)"
            class="px-3 py-1.5 rounded-full text-xs font-medium transition-all"
            :style="form.avoidGroups.includes(g)
              ? 'background:#FEE2E2;color:#991B1B'
              : 'background:#f9fafb;color:#9ca3af'">
            <span v-if="form.avoidGroups.includes(g)">✕ </span>{{ g }}
          </button>
        </div>
      </div>
    </div>

    <!-- CTA -->
    <button @click="generate" :disabled="!canGenerate"
      class="w-full mt-5 py-4 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2 active:scale-95 transition-transform disabled:opacity-40"
      style="background:linear-gradient(135deg,#1a1a2e,#2d2d5e); box-shadow:0 6px 20px rgba(26,26,46,0.25)">
      <span class="text-xl">✨</span>
      Générer ma séance
    </button>

    <p v-if="quotaReached" class="text-center text-xs text-red-500 mt-2">
      Quota atteint pour aujourd'hui. Reviens demain.
    </p>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useBotStore } from '@/stores/bot'
import { useWorkoutsStore } from '@/stores/workouts'
import { useStatsStore } from '@/stores/stats'
import { callCoach, buildWorkoutPayload, parseWorkoutResponse, getTodayUsage } from '@/lib/coach'

const bot = useBotStore()
const workouts = useWorkoutsStore()
const stats = useStatsStore()

const form = ref({
  objective: 'wod',
  duration: 45,
  equipment: 'gym',
  avoidGroups: []
})

const objectiveOptions = [
  { value: 'force',    label: 'Force',    icon: '🏋️', color: '#1a1a2e' },
  { value: 'cardio',   label: 'Cardio',   icon: '❤️', color: '#E24B4A' },
  { value: 'wod',      label: 'WOD',      icon: '🔥', color: '#A32D2D' },
  { value: 'hyrox',    label: 'Hyrox',    icon: '🏃', color: '#EF9F27' },
  { value: 'mobility', label: 'Mobilité', icon: '🧘', color: '#37BFAD' }
]

const equipmentOptions = [
  { value: 'gym',        label: 'Salle complète',  icon: '🏋️' },
  { value: 'home',       label: 'Home gym',        icon: '🏠' },
  { value: 'bodyweight', label: 'Poids du corps',  icon: '💪' },
  { value: 'outdoor',    label: 'Extérieur',       icon: '🌳' }
]

const avoidableGroups = ['Pectoraux', 'Dos', 'Épaules', 'Bras', 'Jambes', 'Fessiers', 'Abdos']

const quotaReached = computed(() => bot.todayUsage >= bot.dailyQuota)
const canGenerate = computed(() => !quotaReached.value && !bot.aiLoading)

function toggleAvoid(g) {
  const idx = form.value.avoidGroups.indexOf(g)
  if (idx >= 0) form.value.avoidGroups.splice(idx, 1)
  else form.value.avoidGroups.push(g)
}

async function generate() {
  if (!canGenerate.value) return
  bot.setAiLoading(true, 0)
  bot.setAiError(null)

  try {
    // Préparer le payload avec données utilisateur
    const recentSessions = stats.sessions?.slice(0, 5) || []
    const prs = await collectPRs()
    const frequencyPerWeek = stats.weekCount || 0

    const payload = buildWorkoutPayload({
      objective: form.value.objective,
      duration: form.value.duration,
      equipment: form.value.equipment,
      avoidGroups: form.value.avoidGroups,
      availableExercises: workouts.exercises,
      recentSessions,
      prs,
      frequencyPerWeek
    })

    // Animation des étapes pendant que l'IA travaille
    const stepInterval = setInterval(() => {
      if (bot.aiLoadingStep < 3) bot.aiLoadingStep++
    }, 1800)

    const response = await callCoach('generate_workout', payload)

    clearInterval(stepInterval)
    bot.aiLoadingStep = 4

    // Parser le JSON de l'IA
    const parsed = parseWorkoutResponse(response.content)

    // Update quota
    if (response.quota) {
      bot.setQuota(response.quota.used, response.quota.limit)
    }

    // Afficher le résultat
    bot.goToAiResult(parsed)

  } catch (e) {
    if (e.code === 'QUOTA_EXCEEDED') {
      bot.setQuota(e.used, e.limit)
      bot.setAiError(`Quota quotidien atteint (${e.limit}/jour). Reviens demain !`)
    } else {
      bot.setAiError(e.message || 'Erreur lors de la génération')
    }
  } finally {
    bot.setAiLoading(false, 0)
  }
}

async function collectPRs() {
  // Construit la liste des PR à partir des sessions stockées
  const prs = []
  const seen = new Set()
  for (const session of stats.sessions || []) {
    for (const set of session.session_sets || []) {
      if (set.pr && !seen.has(set.exercise_id)) {
        const ex = workouts.exercises.find(e => e.id === set.exercise_id)
        if (ex) {
          prs.push({
            exercise_name: ex.name,
            weight_kg: set.weight_kg,
            reps_done: set.reps_done
          })
          seen.add(set.exercise_id)
        }
      }
    }
    if (prs.length >= 10) break
  }
  return prs
}

onMounted(async () => {
  // Charger les exos et stats si pas déjà fait
  await Promise.all([
    workouts.exercises.length === 0 ? workouts.fetchExercises() : null,
    stats.sessions?.length === 0 ? stats.fetchSessions(20) : null
  ])

  // Récupérer le quota du jour
  const used = await getTodayUsage()
  bot.setQuota(used)
})
</script>
