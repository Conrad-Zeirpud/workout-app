<template>
  <div v-if="bot.aiResult" class="px-4 py-4 pb-32">
    <!-- Header avec nom de la séance -->
    <div class="card p-4 mb-4" style="background:linear-gradient(135deg,#FEF3C7,#FDE68A); border:none">
      <div class="flex items-start gap-3">
        <span class="text-3xl">{{ catIcon }}</span>
        <div class="flex-1 min-w-0">
          <p class="text-xs font-semibold uppercase tracking-wide text-amber-700">
            ✨ Séance générée par l'IA
          </p>
          <h2 class="font-bold text-gray-900 mt-1">{{ bot.aiResult.name }}</h2>
          <p class="text-xs text-gray-600 mt-1">{{ bot.aiResult.description }}</p>
        </div>
      </div>
    </div>

    <!-- Notes du coach -->
    <div v-if="bot.aiResult.coach_notes"
      class="card p-3 mb-4"
      style="background:#F0F9FF; border-left:3px solid #378ADD">
      <p class="text-xs font-semibold text-blue-700 mb-1">💡 Notes du coach</p>
      <p class="text-sm text-gray-700">{{ bot.aiResult.coach_notes }}</p>
    </div>

    <!-- Sections -->
    <div v-if="warmupItems.length" class="mb-3">
      <div class="flex items-center gap-2 mb-2 px-1">
        <span class="text-xl">🔥</span>
        <p class="text-sm font-semibold text-gray-900">Échauffement</p>
        <span class="text-xs text-gray-400">({{ warmupItems.length }})</span>
      </div>
      <div class="space-y-1.5">
        <ItemRow v-for="(item, i) in warmupItems" :key="i" :item="item" :exercises="workouts.exercises" />
      </div>
    </div>

    <div v-if="mainItems.length" class="mb-3">
      <div class="flex items-center gap-2 mb-2 px-1">
        <span class="text-xl">💪</span>
        <p class="text-sm font-semibold text-gray-900">Exercices</p>
        <span class="text-xs text-gray-400">({{ mainItems.length }})</span>
      </div>
      <div class="space-y-1.5">
        <ItemRow v-for="(item, i) in mainItems" :key="i" :item="item" :exercises="workouts.exercises" />
      </div>
    </div>

    <div v-if="wodItems.length" class="mb-3">
      <div class="flex items-center gap-2 mb-2 px-1">
        <span class="text-xl">🏁</span>
        <p class="text-sm font-semibold text-gray-900">WOD</p>
        <span v-if="bot.aiResult.wod_mode" class="badge bg-red-100 text-red-700 text-xs">
          {{ wodModeLabel }}
        </span>
      </div>
      <div class="space-y-1.5">
        <ItemRow v-for="(item, i) in wodItems" :key="i" :item="item" :exercises="workouts.exercises" />
      </div>
      <p v-if="wodConfigLabel" class="text-xs text-gray-500 mt-2 text-center">
        ⏱ {{ wodConfigLabel }}
      </p>
    </div>

    <!-- Actions -->
    <div class="space-y-2 mt-5">
      <button @click="saveAndOpen"
        :disabled="saving"
        class="w-full py-3 rounded-2xl text-white font-bold flex items-center justify-center gap-2 active:scale-95 transition-transform disabled:opacity-40"
        style="background:linear-gradient(135deg,#1a1a2e,#2d2d5e)">
        <span v-if="saving" class="animate-spin">⟳</span>
        <span v-else>💾</span>
        Enregistrer dans mes séances
      </button>
      <button @click="saveAndEdit"
        :disabled="saving"
        class="w-full py-3 rounded-xl bg-blue-50 text-blue-700 font-medium flex items-center justify-center gap-2 active:scale-95 transition-transform disabled:opacity-40">
        <span>✏️</span>
        Modifier dans le constructeur
      </button>
      <button @click="bot.goToAiGenerate()"
        class="w-full py-2 text-gray-500 text-sm">
        🔄 Refaire avec d'autres critères
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, h } from 'vue'
import { useRouter } from 'vue-router'
import { useBotStore } from '@/stores/bot'
import { useWorkoutsStore } from '@/stores/workouts'
import { useToast } from '@/composables/useToast'

const bot = useBotStore()
const workouts = useWorkoutsStore()
const router = useRouter()
const { show } = useToast()
const saving = ref(false)

// Sub-component inline pour les rangées d'exercices
const ItemRow = {
  props: ['item', 'exercises'],
  setup(props) {
    const ex = props.exercises.find(e => e.id === props.item.exercise_id)
    return () => h('div', { class: 'p-2.5 bg-white rounded-xl flex items-center gap-2 text-sm' }, [
      h('span', { class: 'text-base' }, '💪'),
      h('div', { class: 'flex-1 min-w-0' }, [
        h('p', { class: 'font-medium text-gray-900 truncate' }, ex?.name || 'Exercice'),
        h('p', { class: 'text-xs text-gray-500' }, describeItem(props.item))
      ])
    ])
  }
}

function describeItem(item) {
  const parts = []
  if (item.sets) parts.push(`${item.sets} séries`)
  if (item.reps) parts.push(`${item.reps} reps`)
  if (item.weight_kg && item.weight_kg > 0) parts.push(`${item.weight_kg}kg`)
  if (item.rest_seconds) parts.push(`repos ${item.rest_seconds}s`)
  return parts.join(' · ')
}

const warmupItems = computed(() =>
  (bot.aiResult?.items || []).filter(i => i.section === 'warmup').sort((a, b) => (a.order || 0) - (b.order || 0))
)
const mainItems = computed(() =>
  (bot.aiResult?.items || []).filter(i => i.section === 'main').sort((a, b) => (a.order || 0) - (b.order || 0))
)
const wodItems = computed(() =>
  (bot.aiResult?.items || []).filter(i => i.section === 'wod').sort((a, b) => (a.order || 0) - (b.order || 0))
)

const catIcon = computed(() => ({
  athx: '⚡', renfo: '💪', hyrox: '🏃', crossfit: '🔥',
  cardio: '❤️', mobility: '🧘', other: '🏋️'
}[bot.aiResult?.category] || '✨'))

const wodModeLabel = computed(() => ({
  amrap: '🔁 AMRAP', emom: '⏱️ EMOM', fortime: '🏁 For Time',
  tabata: '🔥 Tabata', interval: '🔂 Intervalles'
}[bot.aiResult?.wod_mode] || ''))

const wodConfigLabel = computed(() => {
  const mode = bot.aiResult?.wod_mode
  const c = bot.aiResult?.wod_config || {}
  if (mode === 'amrap') return `${Math.floor((c.totalSeconds || 0) / 60)} min`
  if (mode === 'emom') return `${c.rounds} rounds × ${formatInterval(c.intervalSeconds)}`
  if (mode === 'fortime') return c.cap > 0 ? `Cap ${Math.floor(c.cap / 60)} min` : 'Sans limite'
  if (mode === 'tabata' || mode === 'interval')
    return `${c.workSeconds}s / ${c.restSeconds}s × ${c.rounds}`
  return ''
})

function formatInterval(sec) {
  if (!sec) return ''
  if (sec < 60) return `${sec}s`
  const m = Math.floor(sec / 60)
  return `${m}min`
}

async function persistWorkout() {
  const result = bot.aiResult
  if (!result) throw new Error('Pas de séance générée')

  // 1. Créer le workout
  const workout = await workouts.createWorkout({
    name: result.name,
    description: result.description || '',
    category: result.category || 'other',
    wod_mode: result.wod_mode || null,
    wod_config: result.wod_config || null
  })

  // 2. Enregistrer les items
  const validItems = (result.items || []).filter(i => {
    return workouts.exercises.some(e => e.id === i.exercise_id)
  })

  if (validItems.length > 0) {
    await workouts.saveWorkoutItems(workout.id, validItems.map((it, idx) => ({
      exercise_id: it.exercise_id,
      sets: it.sets || 3,
      reps: it.reps || 10,
      weight_kg: it.weight_kg || 0,
      rest_seconds: it.rest_seconds || 90,
      section: it.section || 'main',
      order: it.order ?? idx
    })))
  }

  await workouts.fetchWorkouts()
  return workout
}

async function saveAndOpen() {
  saving.value = true
  try {
    await persistWorkout()
    show('Séance enregistrée ✓')
    bot.close()
    router.push('/workouts')
  } catch (e) {
    show(e.message || 'Erreur lors de l\'enregistrement', 'error')
  }
  saving.value = false
}

async function saveAndEdit() {
  saving.value = true
  try {
    const workout = await persistWorkout()
    show('Ouverture dans le constructeur')
    bot.close()
    router.push(`/workouts/edit/${workout.id}`)
  } catch (e) {
    show(e.message || 'Erreur lors de l\'enregistrement', 'error')
  }
  saving.value = false
}
</script>
