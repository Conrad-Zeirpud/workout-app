import { defineStore } from 'pinia'
import { ref } from 'vue'

// Store du bot étendu avec la gestion du Coach IA

export const useBotStore = defineStore('bot', () => {
  // État FAQ (du patch N1-bis)
  const isOpen = ref(false)
  const view = ref('home')           // 'home' | 'category' | 'ai-generate' | 'ai-result'
  const currentCategory = ref(null)
  const expandedId = ref(null)

  // État Coach IA
  const todayUsage = ref(0)
  const dailyQuota = ref(5)
  const aiLoading = ref(false)
  const aiLoadingStep = ref(0)
  const aiResult = ref(null)         // résultat parsé de l'IA
  const aiError = ref(null)

  function open() { isOpen.value = true }
  function close() { isOpen.value = false }

  function goToCategory(catId) {
    currentCategory.value = catId
    view.value = 'category'
    expandedId.value = null
  }

  function backToHome() {
    view.value = 'home'
    currentCategory.value = null
    expandedId.value = null
  }

  function toggleExpand(id) {
    expandedId.value = expandedId.value === id ? null : id
  }

  function goToAiGenerate() {
    view.value = 'ai-generate'
    aiResult.value = null
    aiError.value = null
  }

  function goToAiResult(result) {
    aiResult.value = result
    view.value = 'ai-result'
  }

  function setAiLoading(loading, step = 0) {
    aiLoading.value = loading
    aiLoadingStep.value = step
  }

  function setAiError(error) {
    aiError.value = error
  }

  function setQuota(used, limit) {
    todayUsage.value = used
    if (limit) dailyQuota.value = limit
  }

  return {
    // FAQ
    isOpen, view, currentCategory, expandedId,
    open, close, goToCategory, backToHome, toggleExpand,
    // AI
    todayUsage, dailyQuota, aiLoading, aiLoadingStep, aiResult, aiError,
    goToAiGenerate, goToAiResult, setAiLoading, setAiError, setQuota
  }
})
