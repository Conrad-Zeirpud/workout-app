<template>
  <transition name="fade">
    <div v-if="bot.aiLoading"
      class="fixed inset-0 z-[60] flex items-center justify-center px-6"
      style="background:rgba(15,15,30,0.95); backdrop-filter:blur(8px)">

      <div class="max-w-sm w-full">
        <div class="text-center mb-8">
          <div class="text-6xl mb-3 inline-block animate-pulse">✨</div>
          <h3 class="text-white text-xl font-bold">Le coach prépare ta séance</h3>
          <p class="text-white/50 text-xs mt-1">Cela peut prendre 5 à 10 secondes</p>
        </div>

        <div class="space-y-3">
          <div v-for="(step, i) in steps" :key="i"
            class="flex items-center gap-3 transition-all duration-500"
            :style="i <= bot.aiLoadingStep ? 'opacity:1' : 'opacity:0.3'">

            <div class="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-colors"
              :style="i < bot.aiLoadingStep
                ? 'background:#22C55E;color:white'
                : i === bot.aiLoadingStep
                  ? 'background:#1a1a2e;color:white'
                  : 'background:#374151;color:#9CA3AF'">
              <span v-if="i < bot.aiLoadingStep" class="text-sm">✓</span>
              <span v-else-if="i === bot.aiLoadingStep" class="animate-spin text-xs">⟳</span>
              <span v-else class="text-xs">{{ i + 1 }}</span>
            </div>

            <p class="text-white text-sm flex-1">{{ step }}</p>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script setup>
import { useBotStore } from '@/stores/bot'

const bot = useBotStore()

const steps = [
  "Analyse de ton profil sportif",
  "Lecture de ton historique et de tes records",
  "Sélection des exercices adaptés",
  "Construction de la séance personnalisée",
  "Finalisation"
]
</script>

<style scoped>
.fade-enter-active, .fade-leave-active { transition: opacity 0.3s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
.animate-spin { animation: spin 1s linear infinite; }
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
.animate-pulse { animation: pulse 2s ease-in-out infinite; }
@keyframes pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.1); } }
</style>
